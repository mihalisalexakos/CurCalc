(node.js needs to be installed)

For backend:
npm install
node app.js

For frontend:
npm install
npm run serve

User credentials for logging in:
Username: username
Password: password